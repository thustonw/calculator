import Foundation

struct Converter{
    var label:String
    var inputUnit:String
    var outputUnit:String
}
