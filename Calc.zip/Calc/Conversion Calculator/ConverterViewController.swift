import UIKit


class ConverterViewController: UIViewController {
    
    var inputText:String = ""
    var outputText:String = ""
    
    var currentConverter:Converter = Converter(label: "fahrenheit to celcius", inputUnit: " °F", outputUnit: " °C")

    let converters:[Converter] = [
        Converter(label: "Fahrenheit to Celcius!!", inputUnit: " °F", outputUnit: " °C"),
        Converter(label: "Celcius to Fahrenheit!!", inputUnit: " °C", outputUnit: " °F"),
        Converter(label: "Miles to Kilometers!!", inputUnit: " mi", outputUnit: " km"),
        Converter(label: "Kilometers to Miles!!", inputUnit: " km", outputUnit: " mi")
    ]

    @IBOutlet weak var outputDisplay: UITextField!
    @IBOutlet weak var inputDisplay: UITextField!
    
    @IBAction func buttonPress(_ sender: UIButton) {
        
        switch sender.tag{
        case 0:
            handleNumberPressed(num: sender.titleLabel!.text!)
        case 1:
            handleConvertPressed()
        case 2:
            handleSignChange()
        case 3:
            handleDecimal()
        case 4:
            clear()
        default:
            break
        }
    }
    
    func handleConvertPressed(){
        let alert = UIAlertController(title: nil, message: "Choose Converter", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        for converter in converters{
            alert.addAction(UIAlertAction(title: converter.label, style: UIAlertActionStyle.default, handler: {
                (alertAction) -> Void in
                self.currentConverter = converter
                self.inputDisplay.text = self.inputText + converter.inputUnit
                if let input = Double(self.inputText){
                    self.outputText = String(format: "%.2f", self.calculateConversion(input: input))
                }
                self.outputDisplay.text = self.outputText + converter.outputUnit
            }))
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func handleNumberPressed(num:String){
        inputText.append(num)
        self.inputDisplay.text = inputText + currentConverter.inputUnit
        if let input = Double(inputText){
            outputText = String(format: "%.2f", calculateConversion(input: input))
        }
        self.outputDisplay.text = outputText + currentConverter.outputUnit
    }
    
    func calculateConversion(input:Double) -> Double{
        
        var output:Double = 0.0
        
        switch currentConverter.label{
            case "Fahrenheit to Celcius!!":
                output = (input - 32) * (5/9)
            case "Celcius to Fahrenheit!!":
                output = input * (9/5) + 32
            case "Miles to Kilometers!!":
                output = input / 0.62137
            case "Kilometers to Miles!!":
                output = input * 0.62137
            default:
                break
        }
        return output
    }
    
    func handleSignChange(){
        if(!self.inputText.isEmpty){
            if(self.inputText.first != "-"){
                self.inputText = "-" + self.inputText
            }else{
                self.inputText.remove(at: self.inputText.index(of: "-")!)
            }
            self.outputText = String(format: "%.2f", calculateConversion(input: Double(self.inputText)!))
            self.inputDisplay.text = inputText + currentConverter.inputUnit
            self.outputDisplay.text = outputText + currentConverter.outputUnit
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
        let defaultConverter = converters[0]
        currentConverter = defaultConverter
        inputDisplay.text = defaultConverter.inputUnit
        outputDisplay.text = defaultConverter.outputUnit
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func clear(){
        self.inputText = ""
        self.outputText = ""
        self.inputDisplay.text = inputText + currentConverter.inputUnit
        self.outputDisplay.text = outputText + currentConverter.outputUnit
    }
    
    func handleDecimal(){
        if(!self.inputText.contains(".") && self.inputText.last != "."){
            self.inputText.append(".")
            self.inputDisplay.text = inputText + currentConverter.inputUnit
            self.outputDisplay.text = outputText + currentConverter.outputUnit
        }
    }

}
